//All JavaScript code by Blake Wood Jr.
var displayBar = document.getElementById("displayBar");

var timesButton = getElementById("timesButton");

                                              
